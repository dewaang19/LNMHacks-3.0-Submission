1 first you need to have netbeans and mysql
2 then you need to create a database names electra and put in the following codes as inputs for creating tables-

mysql> use electra;
Database changed

mysql> create table admin(
     name varchar(30),
     emailID varchar(40),
     password varchar(20)
     primary key(name));


mysql> create table sales_d(
       sno int(11),
       invoiceno int(11),
       item varchar(20)
       primary key(sno));

mysql> create table sales_m(
      cust_name varchar(100),
      dop date,
      payment varchar(50),
      amount decimal(10,2),
      invoiceno int(11),
      primary key(invoiceno));

mysql> create table songs(
      name varchar(100),
      artist varchar(40),
      genre varchar(20),
      year varchar(4),
      price decimal(5,2));

mysql> create table users(
      name varchar(30),
      emailID varchar(40),
      password varchar(20),
      primary key(name));



after inputing tese the you need to change the working directory of the netbeans folder BY BROWSING IT.
 then you need to create an account using sign up 1st entry shoud be of anirudh as the username and password as qwerty 
then after you can create n nuber of accounts after then you need to add stock using username anirudh 
and then after you can use the other accounts to buy the music files as an demo and you can print out an actual hardcopy.